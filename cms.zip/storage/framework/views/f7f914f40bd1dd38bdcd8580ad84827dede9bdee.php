<?php $__env->startSection('title', 'Manage-User'); ?>

<?php $__env->startSection('content'); ?>
<style>
    tr.text-center td{
        vertical-align: middle
    }
</style>
<div class="container">
    <a href="/user/cetak_pdf" class="btn btn-success"target="_blank">CETAK PDF <i class="fas fa-file-pdf"></i></a>
    <p class=" font-weight-bold" style="font-size: 50px;">Table User</p>
    <table class="table table-bordered table-striped">
        <thead>
            <tr class=" text-center">
                <th>Image</th>
                <th>Nama</th>
                <th>E-mail</th>
                <th>Roles</th>
                <th><i class="fas fa-edit"></i></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class=" text-center">
                    <td><img height="80px" src="<?php echo e(asset('/storage/'.$u->image)); ?>"></td>
                    <td><?php echo e($u->name); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><?php echo e($u->roles); ?></td>
                    <td>
                        <a href="user/delete/<?php echo e($u->id); ?>" class="badge badge-danger">Hapus</a>
                        <a href="user/edit/<?php echo e($u->id); ?>" class="badge badge-primary">Edit</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table> 
    <a href="user/add" class="btn btn-primary mb-5">Tambah Data</a>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/manage/manageUser.blade.php ENDPATH**/ ?>