 

 <?php $__env->startSection('title', 'Recipe-Detail'); ?>
 
 <?php $__env->startSection('content'); ?>
 
 <div class="recipePop">
     
     <div class="container"> 
         <div class="titlePop">
             <div class="row">
                 <div class="col-md-7">
                     <h5 class="card-title"><?php echo e(Str::limit($recipe->title, 50, '...')); ?></h5>
                     <p class="card-text text-align: justify;" style="font-family: poppins"><?php echo e($recipe->content); ?></p>
                     <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                     <a href="/recipeAll/cetak_pdf/<?php echo e($recipe->id); ?>" class="btn btn-success"target="_blank">CETAK PDF <i class="fas fa-file-pdf"></i> </a>         
                 </div>
                 <div class="col-md-5">
                     <img class="img-top" src="<?php echo e(asset('/storage/'.$recipe->featured_image)); ?>" alt="">
                 </div>
             </div>
         </div>
         <div class="article row">
            <?php echo $__env->make('layouts.ingreMet2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="card my-5 mb-5" style="width: 160vh">
             <h5 class="card-header bg-dark-gray">Leave a Comment</h5>
             <div class="card-body">  
                 <form action="" method="post">
                 <?php echo e(csrf_field()); ?>

                 <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                          <p>Name : <?php echo e(Auth::user()->name); ?></p>  
                     <div class="form-group">
                         <input class="form-control" type="hidden" name="nama" value="<?php echo e(Auth::user()->name); ?>" >
                     </div>
                     <div class="form-group">
                          <p>Comment :</p>  
                         <input class="form-control" type="text" name="komentar">
                     </div>
                     <input type="submit" class="btn btn-primary">
                 </form>
             </div>
         </div>
         <?php $__currentLoopData = $komen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if($k->id_article==$id): ?>
         <div class="media mb-4"> 
            <img class=" mr-3 rounded-circle" width="50px" src="<?php echo e(asset('/storage/'.Auth::user()->image)); ?>" alt="">
             <div class="media-body">
                 <h5 class="mt-0" style="font-size: 20px;"><?php echo e($k->name); ?></h5>
                 <p><?php echo e($k->comment); ?></p>
             </div>
         </div>
         <?php endif; ?>            
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>  
     <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </div>
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/recipeAll.blade.php ENDPATH**/ ?>