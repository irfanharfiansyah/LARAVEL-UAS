<?php $__env->startSection('title', 'Manage-User'); ?>

<?php $__env->startSection('content'); ?>
<style>
    tr.text-center td{
        vertical-align: middle
    }
</style>
<div class="container">
    <p class=" font-weight-bold" style="font-size: 50px;">Table Comment User</p>
    <table class="table table-bordered table-striped">
        <thead>
            <tr class=" text-center">
                <th>Image</th>
                <th>Nama</th>
                <th>Comment</th>
                <th><i class="fas fa-edit"></i></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class=" text-center">
                    <td> <img class=" mr-3"  width="80px" src="<?php echo e(asset('/storage/'.Auth::user()->image)); ?>" alt=""></td>
                    <td><?php echo e($u->name); ?></td>
                    <td class=" text-danger"><?php echo e($u->comment); ?></td>
                    <td>
                        <a href="manageCom/delete/<?php echo e($u->id); ?>" class="badge badge-danger">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/manage/manageCom.blade.php ENDPATH**/ ?>