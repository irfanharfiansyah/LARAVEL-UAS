  
<!DOCTYPE html>
<html>
<head>
<title>Laporan Artikel Recipe</title>
</head>
<body>
    <style>
        table {
        width:100%;
      }
      table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
      }
      th, td {
        padding: 15px;
        text-align: center;
      }
    </style>
<center>
<h2>Laporan Artikel Recipe</h2>
</center>
<table class='table table-bordered'>
<thead>
    <tr>
        <th>No</th>
        <th>Judul</th>
        <th>Deskripsi</th>
        <th>Image</th>
    </tr>
</thead>
<tbody>
<?php $i=1 ?>
<?php $__currentLoopData = $recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td style="text-align: justify;"><?php echo e($i++); ?></td>
    <td style="text-align: justify;"><?php echo e($a->title); ?></td>
    <td style="text-align: justify;"><?php echo e($a->content); ?></td>
    <td><img height="99px" width="150px" src="<?php echo e(public_path('storage/'.$a->featured_image)); ?>" style="object-fit: cover"></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</body>
</html><?php /**PATH E:\LaravelUas\cms\resources\views/ReportAdm/recipe_pdf.blade.php ENDPATH**/ ?>