<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<header>
    <section class="home">
        <div class="container">
            <p><span> GOOD FOOD</span> choices are <br> good investments.</p>
            <p>There is a powerful need for symbolism, and that means the architecture must <br>
                have something that appeals to the human heart.</p>
            <a href="#"><button>Try Now</button></a>
        </div>
    </section>  
</header>   
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/home.blade.php ENDPATH**/ ?>