<section class="py-5">
    <div class="row">
        <div class="col-md-6 ">
                <h6 style="font-weight: bold;">INGREDIENTS</h6>
            <blockquote class="blockquote blockquote-custom bg-white p-5 shadow rounded">
                <p class="mb-0 mt-2 font-italic"><?php echo e($popular->ingredient); ?></p>
                <footer class="blockquote-footer pt-4 mt-4 border-top">Someone famous in
                    <cite title="Source Title">Source Title</cite>
                </footer>
            </blockquote>
        </div>
        <div class="col-md-6 ">
                <h6 style="font-weight: bold;">METHODS</h6>
            <blockquote class="blockquote blockquote-custom bg-white p-5 shadow rounded">
                <p class="mb-0 mt-2 font-italic d-block"><?php echo e($popular->method); ?> </p>
                <footer class="blockquote-footer pt-4 mt-4 border-top">Someone famous in
                    <cite title="Source Title">Source Title</cite>
                </footer>
            </blockquote>
        </div>
    </div>
</section><?php /**PATH E:\LaravelUas\cms\resources\views/layouts/recipe.blade.php ENDPATH**/ ?>