<!DOCTYPE html>
<html>
<head>
<title>Laporan Artikel Drink</title>
<style>
  table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: center;
}
    </style>
</head>
<body>
<center>
<h2>Laporan Artikel User</h2>
</center>
<table>
    <tr>
        <th>No</th>
        <th>Photo</th>
        <th>Name</th>
        <th>Email</th>
        <th>Roles</th>   
    </tr>
<?php $i=1 ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($i++); ?></td>
    <td><img width="50px" src="<?php echo e(public_path('storage/'.$a->image)); ?>"></td>
    <td><?php echo e($a->name); ?></td>
    <td><?php echo e($a->email); ?></td>
    <td><?php echo e($a->roles); ?></td>    
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH E:\LaravelUas\cms\resources\views/ReportAdm/User_pdf.blade.php ENDPATH**/ ?>