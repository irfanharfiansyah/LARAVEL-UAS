<?php $__env->startSection('title', 'Manage-Article'); ?>

<?php $__env->startSection('content'); ?>
<p class=" font-weight-bold" style="font-size: 50px;">Edit Data</p>
<form action="/recipeAll/update/<?php echo e($recipe->id); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($recipe->id); ?>"></br>
    <div class="form-group">
        <label for="title">Judul</label>
        <input type="text" class="form-control" required="required" name="title" value="<?php echo e($recipe->title); ?>"></br>
    </div>
    <div class="form-group">
        <label for="content">Content</label>
        <input type="text" class="form-control" required="required" name="content" value="<?php echo e($recipe->content); ?>"></br>
    </div>
    <div class="form-group">
        <h6>Ingredient</h6>
        <textarea type="text" name="ingredient"  id="" cols="80" rows="9" style="margin-bottom: 20px" value="<?php echo e($recipe->ingredient); ?>"><?php echo $recipe['ingredient'] ?></textarea>
    </div>
    <div class="form-group">
        <h6>Method</h6>
        <textarea type="text" name="method"  id="" cols="80" rows="9" style="margin-bottom: 20px" value="<?php echo e($recipe->method); ?>"><?php echo $recipe['method'] ?></textarea>
    </div>
    <div class="form-group">
        <label for="image">Image</label>
        <input type="file" class="form-control" required="required" name="image" value="<?php echo e($recipe->featured_image); ?>"></br>
        <img width="150px" src="<?php echo e(asset('storage/'.$recipe->featured_image)); ?>">
    </div>
    <button type="submit" name="edit" class="btn btn-primary float-right mb-5">Ubah Data</button>
    </form>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/manage/editAll.blade.php ENDPATH**/ ?>