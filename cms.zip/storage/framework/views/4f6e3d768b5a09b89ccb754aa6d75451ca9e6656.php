<?php $__env->startSection('title', 'Manage-Article'); ?>

<?php $__env->startSection('content'); ?>
<p class=" font-weight-bold" style="font-size: 50px;">Edit Data</p>
<form action="/user/update/<?php echo e($user->id); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($user->id); ?>"></br>
    <div class="form-group">
        <label for="name">Nama</label>
        <input type="text" class="form-control" required="required" name="name" value="<?php echo e($user->name); ?>"></br>
    </div>
    <div class="form-group">
        <label for="email">E-mail</label>
        <input type="text" class="form-control" required="required" name="email" value="<?php echo e($user->email); ?>"></br>
    </div>
    <div class="form-group">
        <label for="roles" name="roles" value="<?php echo e($user->roles); ?> ">Roles</label>
        <select id="roles" class="form-control" name="roles" >
            <option value="<?php echo e($user->roles); ?>"><?php echo e($user->roles); ?></option>
            <option name="roles" value="<?php echo e($user->roles); ?>">Admin</option>
            <option name="roles" value="<?php echo e($user->roles); ?>">User</option>
        </select>
    </div>
    <div class="form-group">
        <label for="image">Photo</label>
        <input type="file" class="form-control" required="required" name="image" value="<?php echo e($user->featured_image); ?>"></br>
    </div>
    <img height="120px" src="<?php echo e(asset('/storage/'.$user->image)); ?>" style="border: 1px solid rgba(161, 161, 161, 0.582)">
    <button type="submit" name="edit" class="btn btn-primary float-right">Ubah Data</button>
    </form>
 <?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/manage/editUser.blade.php ENDPATH**/ ?>