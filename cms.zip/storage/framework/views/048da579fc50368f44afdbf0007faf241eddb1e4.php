<?php $__env->startSection('title', 'Recipe-All'); ?>

<?php $__env->startSection('content'); ?>
<div class="recipeAll">
  <div class="content-all">
    <p class="titleAll">Enjoy Cooking</p>
    <img class="logo" src="/img/logo.png" alt="tungguu">
  </div>
  <div class="container">
    <p class="food">FOOD</p>
    <form action="/searchAll" method="GET" class="los form-inline">
      <input class="form-control mr-sm-2 text-dark" type="text" placeholder="Search" name="search"   style="outline: none">
      <button class="btn btn-dark " type="submit"><i class="fas fa-search"></i></button>
    </form>
    <div class="content-recipe ">
      <?php $__currentLoopData = $recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6">
        <div class="all card mb-3" style="width: 33rem;">
          <div class="row no-gutters">
            <div class="col-md-4">
              <img src="<?php echo e(asset('/storage/'.$r->featured_image)); ?>" class="card-img" alt="..." style="height: 320px;">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title"><?php echo e(Str::limit($r->title, 30, '...')); ?></h5>
                <p class="card-text"><?php echo e(Str::limit($r->content, 150, '...')); ?></p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                <a href="<?php echo e('recipeAll/recipe/'.$r->id); ?>"><button class="goRecipe"><i class="fas fa-arrow-right"></i></button></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($recipe->links()); ?>

  </div>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/recipe.blade.php ENDPATH**/ ?>