<?php $__env->startSection('title', 'Manage-Article'); ?>

<?php $__env->startSection('content'); ?>
<style>
    tr.text-center td{
        vertical-align: middle
    }
</style>
<div class="container">
    <a href="/recipeAll/cetak_pdf" class="btn btn-success"target="_blank">CETAK PDF <i class="fas fa-file-pdf"></i> </a>
    <p class=" font-weight-bold" style="font-size: 50px;">Table All Recipe</p>
    <table class="table table-bordered table-striped">
        <thead>
            <tr class=" text-center">
                <th>No</th>
                <th>Judul</th>
                <th>Deskripsi</th>
                <th>Image</th>
                <th><i class="fas fa-edit"></i></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class=" text-center">
                    <td><?php echo e($a->id); ?></td>
                    <td><?php echo e($a->title); ?></td>
                    <td style="text-align: justify;"><?php echo e($a->content); ?></td>
                    <td><img height="99px" width="150px" src="<?php echo e(asset('/storage/'.$a->featured_image)); ?>" style="object-fit: cover"></td>
                    <td >
                        <a href="recipeAll/delete/<?php echo e($a->id); ?>" class="badge badge-danger">Hapus</a>
                        <a href="recipeAll/edit/<?php echo e($a->id); ?>" class="badge badge-primary">Edit</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table> 
    <a href="recipeAll/add" class="btn btn-primary mb-5">Tambah Data</a>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LaravelUas\cms\resources\views/manage/manageAll.blade.php ENDPATH**/ ?>